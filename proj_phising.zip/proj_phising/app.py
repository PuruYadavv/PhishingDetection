from flask import Flask, render_template, request, jsonify
import re
import urllib.parse
import requests

app = Flask(__name__)

SUSPICIOUS_KEYWORDS = [
    'login', 'signin', 'verify', 'update', 'secure', 'banking',
    'account', 'webscr', 'ebayisapi', 'reset', 'confirm', 'pay', 'password'
]

SUSPICIOUS_TLDS = ['.tk', '.ml', '.ga', '.cf', '.gq']

def extract_features(url):
    parsed_url = urllib.parse.urlparse(url)
    features = {
        'url_length': len(url),
        'num_dots': url.count('.'),
        'num_hyphens': url.count('-'),
        'contains_ip': bool(re.search(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', url)),
        'contains_at': '@' in url,
        'suspicious_keywords': any(word in url.lower() for word in SUSPICIOUS_KEYWORDS),
        'tld_suspicious': any(parsed_url.netloc.endswith(tld) for tld in SUSPICIOUS_TLDS),
        'has_double_slash_redirect': url.count('//') > 1,
        'is_long_domain': len(parsed_url.netloc) > 30,
        'has_encoded_chars': '%' in url,
    }
    return features

def is_phishing_url(url):
    features = extract_features(url)
    score = 0

    if features['url_length'] > 75:
        score += 1
    if features['num_dots'] > 4:
        score += 1
    if features['num_hyphens'] > 3:
        score += 1
    if features['contains_ip']:
        score += 2
    if features['contains_at']:
        score += 2
    if features['suspicious_keywords']:
        score += 2
    if features['tld_suspicious']:
        score += 2
    if features['has_double_slash_redirect']:
        score += 1
    if features['is_long_domain']:
        score += 1
    if features['has_encoded_chars']:
        score += 1

    return score >= 5

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/check', methods=['POST'])
def check_url():
    url = request.json.get('url')

    if not url.startswith("http://") and not url.startswith("https://"):
        url = "http://" + url

    try:
        response = requests.get(url, timeout=5)
        if response.status_code >= 400:
            return jsonify({'result': '❌ Site does not exist or URL is broken'})
    except requests.exceptions.RequestException:
        return jsonify({'result': '❌ Site does not exist or URL is broken'})

    is_phishing = is_phishing_url(url)
    return jsonify({'result': '❌ Phishing Site' if is_phishing else '✅ Safe Site'})

if __name__ == '__main__':
    app.run(debug=True)
